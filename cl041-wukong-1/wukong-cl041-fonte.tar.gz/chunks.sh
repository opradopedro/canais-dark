#!/bin/bash
cd /tmp/claude-0/wk2
for a in $(seq 0 150 2621); do
  b=$((a+149)); [ $b -gt 2621 ] && b=2621; r=$a-$b
  [ -s out/c_$r.mp4 ] && continue
  for try in 1 2; do
    node render.mjs out/c_$r.mp4 $r 4 1 > out/c_$r.log 2>&1 && break
    rm -rf /tmp/remotion-webpack-bundle-*
  done
  rm -rf /tmp/remotion-webpack-bundle-*
  echo "chunk $r $(stat -c %s out/c_$r.mp4 2>/dev/null)"
done
echo ALLDONE
