import React from "react";
import { Composition } from "remotion";
import { WukongShort, WUKONG_FRAMES } from "./videos/wukong/Wukong";
export const Root: React.FC = () => (<>
  <Composition id="WukongShort" component={WukongShort} durationInFrames={WUKONG_FRAMES} fps={30} width={1080} height={1920} />
</>);
