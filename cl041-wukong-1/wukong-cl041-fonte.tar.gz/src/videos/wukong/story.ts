// Sun Wukong part 1 (Old Tales, ~87 s): shot table, cameras and lens blur, timed to voice/words.json.
export const FPS = 30;
export const TOTAL = 2622; // 87.4 s = voice length; nothing plays after the narration
export type V3 = [number, number, number];
export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const smooth = (x: number) => { const u = clamp01(x); return u * u * (3 - 2 * u); };
export const glide = (u: number) => { const x = clamp01(u); return x * x * x * (x * (6 * x - 15) + 10); };
const F = (s: number) => Math.round(s * FPS);

// word onsets used by the picture (seconds, words.json)
export const W = {
  moonlight: 14.25, cracks: 18.63, open: 20.03, eyes: 25.66, shoot: 25.98, shrugs: 32.04, strange: 34.08, letBe: 36.0,
  plays: 39.0, waterfall: 43.11, shout: 47.09, nobody: 49.6, stay: 54.1, closes: 59.22, leaps: 60.84, beds: 65.45,
  bows: 69.21, king: 71.93, years: 75.19, feast: 79.12, cry: 81.08, why: 82.7, follow: 85.46,
};
export const LEAP_T0 = 60.95;

export type Light = "day" | "golden";
export type Place = "peak" | "cave" | "heaven";
export type ShotDef = { id: number; a: number; b: number; light: Light; place: Place };
export const SHOTS: ShotDef[] = [
  { id: 1, a: 0, b: F(5.6), light: "day", place: "peak" },          // the stone (aerial in)
  { id: 2, a: F(5.6), b: F(11.4), light: "day", place: "peak" },    // Mountain of Flowers and Fruit
  { id: 3, a: F(11.4), b: F(16.6), light: "golden", place: "peak" },// sunlight, moonlight, wind
  { id: 4, a: F(16.6), b: F(21.5), light: "day", place: "peak" },   // cracks open
  { id: 5, a: F(21.5), b: F(25.2), light: "day", place: "peak" },   // out climbs a monkey
  { id: 6, a: F(25.2), b: F(29.2), light: "day", place: "peak" },   // golden light from his eyes
  { id: 7, a: F(29.2), b: F(37.9), light: "day", place: "heaven" }, // the Jade Emperor shrugs
  { id: 8, a: F(37.9), b: F(41.4), light: "day", place: "peak" },   // plays with the other monkeys
  { id: 9, a: F(41.4), b: F(49.4), light: "day", place: "peak" },   // the waterfall dare
  { id: 10, a: F(49.4), b: F(58.2), light: "day", place: "peak" },  // nobody moves
  { id: 11, a: F(58.2), b: F(62.4), light: "day", place: "peak" },  // he leaps
  { id: 12, a: F(62.4), b: F(66.9), light: "day", place: "cave" },  // the dry cave behind
  { id: 13, a: F(66.9), b: F(73.9), light: "day", place: "cave" },  // every monkey bows: the Monkey King
  { id: 14, a: F(73.9), b: F(77.8), light: "day", place: "cave" }, // three hundred years
  { id: 15, a: F(77.8), b: TOTAL, light: "day", place: "cave" },   // the feast, he cries
];
export const XFADE: Record<number, number> = { 3: 10, 4: 10, 14: 12, 15: 10 };
export const FLASH_AT = F(21.5) - 4; // white flash hides the cut from the cracking stone to the monkey
export const shotAt = (f: number) => SHOTS.find((s) => f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];
export const layersAt = (f: number): { id: number; alpha: number }[] => {
  const s = shotAt(f), x = XFADE[s.id];
  if (x && f < s.a + x && s.id > 1) return [{ id: s.id - 1, alpha: 1 }, { id: s.id, alpha: smooth((f - s.a + 1) / x) }];
  return [{ id: s.id, alpha: 1 }];
};

// ---------------- world anchors ----------------
export const EGG: V3 = [0, 0, 0];
export const FALL_X = 15;
export const HEAVEN_Y = 420;
export const CAVE: V3 = [0, -260, 0];
/** monkey leap: summit edge -> through the waterfall */
export const leapAt = (t: number): { p: V3; roll: number; u: number } => {
  const u = clamp01((t - LEAP_T0) / 1.75);
  const x = 6.2 + (FALL_X + 1.5 - 6.2) * u, y = 4.2 * Math.sin(Math.PI * Math.min(1, u * 1.1)) * (1 - 0.25 * u) - 1.2 * u * u;
  return { p: [x, y, 1.6], roll: -0.5 * Math.sin(Math.PI * u), u };
};

// ---------------- cameras ----------------
export type Cam = { pos: V3; look: V3; fov: number; roll: number };
type Key = { f: number; pos: V3; look: V3; fov?: number; roll?: number };
const L = (a: number, b: number, u: number) => a + (b - a) * u;
const L3 = (a: V3, b: V3, u: number): V3 => [L(a[0], b[0], u), L(a[1], b[1], u), L(a[2], b[2], u)];
const H = HEAVEN_Y, C = CAVE;
const KEYS: Record<number, Key[]> = {
  1: [{ f: 0, pos: [-38, 22, 70], look: [0, -2, 0], fov: 42 }, { f: F(5.6), pos: [-6.5, 3.2, 11.5], look: [0, 0.9, 0], fov: 38, roll: 0.02 }],
  2: [{ f: F(5.6), pos: [-30, 9, -26], look: [0, -3, 0], fov: 44 }, { f: F(11.4), pos: [-22, 6, -30], look: [0, -2, 0], fov: 42 }],
  3: [{ f: F(11.4), pos: [-2.2, 1.5, -6.2], look: [0, 1.15, 0], fov: 36 }, { f: F(16.6), pos: [1.6, 1.3, -6.0], look: [0, 1.1, 0], fov: 34 }],
  4: [{ f: F(16.6), pos: [0.6, 1.25, 4.4], look: [0, 1.0, 0], fov: 34 }, { f: F(19.9), pos: [0.4, 1.15, 3.2], look: [0, 1.0, 0], fov: 33 },
    { f: F(21.5), pos: [0.3, 1.1, 2.7], look: [0, 1.0, 0], fov: 34 }],
  5: [{ f: F(21.5), pos: [-0.8, 0.55, 4.2], look: [0, 0.95, 0], fov: 36, roll: -0.03 }, { f: F(25.2), pos: [-0.5, 0.75, 3.1], look: [0, 1.0, 0], fov: 35, roll: -0.03 }],
  6: [
    { f: F(25.2), pos: [0.15, 1.12, 1.75], look: [0, 1.06, 0], fov: 32 },
    { f: F(26.2), pos: [0.12, 1.1, 1.5], look: [0, 1.06, 0], fov: 32 },
    { f: F(27.4), pos: [2.0, 1.4, 5.0], look: [0, 6.0, -0.6], fov: 48 },
    { f: F(29.2), pos: [2.6, 1.8, 6.5], look: [0, 40, -5], fov: 52 },
  ],
  7: [
    { f: F(29.2), pos: [10, H + 3.5, 26], look: [0, H + 4, 0], fov: 42 },
    { f: F(33.4), pos: [3, H + 2.3, 11], look: [-0.6, H + 2.2, 4.8], fov: 36 },
    { f: F(37.9), pos: [0.2, H + 2.4, 8.4], look: [-0.9, H + 2.25, 4.8], fov: 32 },
  ],
  8: [{ f: F(37.9), pos: [-1.0, 1.6, 8.5], look: [1.2, 0.7, 1.0], fov: 42 }, { f: F(41.4), pos: [-0.2, 1.5, 7.2], look: [1.6, 0.7, 1.0], fov: 40 }],
  9: [ // from behind the troop at the edge, the waterfall ahead
    { f: F(41.4), pos: [-1.5, 1.7, 6.0], look: [12, 1.6, 0.5], fov: 50 },
    { f: F(49.4), pos: [0.2, 1.6, 5.4], look: [12, 1.8, 0.5], fov: 46 },
  ],
  10: [ // faces: nobody moves... then our monkey
    { f: F(49.4), pos: [3.6, 1.0, 6.4], look: [6.4, 0.75, 2.0], fov: 38 },
    { f: F(53.9), pos: [4.2, 0.95, 5.6], look: [6.2, 0.8, 2.0], fov: 36 },
    { f: F(54.4), pos: [7.0, 0.75, 5.0], look: [6.2, 0.68, 1.6], fov: 34 },
    { f: F(58.2), pos: [6.9, 0.72, 3.8], look: [6.2, 0.66, 1.6], fov: 32 },
  ],
  11: [{ f: F(58.2), pos: [6.9, 0.72, 3.7], look: [6.2, 0.66, 1.6], fov: 32 }, { f: F(60.8), pos: [6.85, 0.72, 3.3], look: [6.2, 0.66, 1.6], fov: 32 }],
  12: [ // through the water into the dry cave
    { f: F(62.4), pos: [C[0], C[1] + 2.0, C[2] + 17.4], look: [C[0], C[1] + 2.0, C[2]], fov: 46 },
    { f: F(66.9), pos: [C[0] - 2, C[1] + 2.6, C[2] + 7.5], look: [C[0], C[1] + 1.4, C[2] - 5], fov: 42 },
  ],
  13: [
    { f: F(66.9), pos: [C[0] + 5, C[1] + 3.2, C[2] + 9], look: [C[0], C[1] + 1.2, C[2] - 4], fov: 44 },
    { f: F(71.6), pos: [C[0] + 1.5, C[1] + 2.4, C[2] + 3.5], look: [C[0], C[1] + 1.5, C[2] - 8], fov: 40 },
    { f: F(73.9), pos: [C[0] + 0.4, C[1] + 1.9, C[2] - 1.0], look: [C[0], C[1] + 1.6, C[2] - 8], fov: 38 },
  ],
  14: [{ f: F(73.9), pos: [C[0] - 7, C[1] + 4.5, C[2] + 8], look: [C[0], C[1] + 1.2, C[2] - 5], fov: 46 }, { f: F(77.8), pos: [C[0] - 4, C[1] + 3.8, C[2] + 6], look: [C[0], C[1] + 1.2, C[2] - 5], fov: 44 }],
  15: [
    { f: F(77.8), pos: [C[0] + 4.5, C[1] + 2.6, C[2] + 2.5], look: [C[0], C[1] + 1.2, C[2] - 5.5], fov: 42 },
    { f: F(80.6), pos: [C[0] + 2.0, C[1] + 2.2, C[2] - 1.5], look: [C[0], C[1] + 1.5, C[2] - 8], fov: 38 },
    { f: F(84.0), pos: [C[0] + 0.3, C[1] + 1.8, C[2] - 5.2], look: [C[0], C[1] + 1.66, C[2] - 8.1], fov: 34 },
    { f: TOTAL, pos: [C[0] + 0.2, C[1] + 1.75, C[2] - 5.8], look: [C[0], C[1] + 1.66, C[2] - 8.1], fov: 32 },
  ],
};
export const camAt = (id: number, f: number): Cam => {
  const ks = KEYS[id];
  let i = 0;
  while (i < ks.length - 2 && f >= ks[i + 1].f) i++;
  const a = ks[i], b = ks[Math.min(i + 1, ks.length - 1)];
  const u = b.f === a.f ? 0 : glide((f - a.f) / (b.f - a.f));
  let pos = L3(a.pos, b.pos, u), look = L3(a.look, b.look, u);
  let roll = L(a.roll ?? 0, b.roll ?? 0, u);
  const fov = L(a.fov ?? 40, b.fov ?? 40, u);
  if (id === 11 && f >= F(LEAP_T0)) { // track the leap side-on, waterfall ahead
    const lp = leapAt(f / FPS).p;
    const k = smooth((f / FPS - LEAP_T0) / 0.35);
    const tp: V3 = [lp[0] - 2.4, 1.6 + 0.55 * lp[1], lp[2] + 6.2], tl: V3 = [lp[0] + 1.4, 1.2 + 0.6 * lp[1], lp[2]];
    pos = L3(pos, tp, k); look = L3(look, tl, k);
  }
  const kf = f - F(W.open);
  if (id === 4 && kf >= 0 && kf < 6) { const s = (kf % 2 ? -1 : 1) * 0.06 * (1 - kf / 6); pos = [pos[0] + s * 0.4, pos[1] + s * 0.25, pos[2]]; roll += s * 0.3; }
  return { pos, look, fov, roll };
};

export const dofAt = (f: number): { cInf: number } => {
  const s = shotAt(f);
  const m: Record<number, number> = { 1: 0, 2: 0, 3: 9, 4: 13, 5: 11, 6: 13, 7: 8, 8: 9, 9: 0, 10: 11, 11: 12, 12: 0, 13: 6, 14: 0, 15: 10 };
  let c = m[s.id];
  if (s.id === 6 && f > F(27.4)) c = 0;
  if (s.id === 11 && f > F(LEAP_T0)) c = 0;
  return { cInf: c };
};
export const T = F;
